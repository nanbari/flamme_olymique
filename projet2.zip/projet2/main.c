#include <stdio.h>
#include <stdlib.h>
#include "itineraireflamme.h"
#include "region.h"


int main()
{
    

}